/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Questao3;

/**
 *
 * @author Doguinho_a
 */
public class Main {
     public static void main(String[] args){
        Conta_Bancaria ct = new Conta_Bancaria("000001", "013", 100.0, 1);
        ContaImposto cip = new ContaImposto("000001", "013", 100.0, 1);
        
        cip.mostrarSaldo();
        cip.calcularimposto();
        cip.mostrarSaldo();
        cip.sacar(20);
        cip.mostrarSaldo();
        cip.depositar(30);
        cip.mostrarSaldo();
        
    }
}
