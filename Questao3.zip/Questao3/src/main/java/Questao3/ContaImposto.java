/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Questao3;

import java.util.Scanner;

/**
 *
 * @author Doguinho_a
 */
public class ContaImposto extends Conta_Bancaria{
     private double percentualimposto;

    public double getPercentualimposto() {
        return percentualimposto;
    }

    public void setPercentualimposto(double percentualimposto) {
        this.percentualimposto = percentualimposto;
    }

     
    public ContaImposto(String numero, String agencia, double saldo, int codigoTipo) {
        super(numero, agencia, saldo, codigoTipo);
    }
    
    public void calcularimposto(){
     Scanner t = new Scanner(System.in);
     System.out.println("Percentual(%) de Imposoto:");
     percentualimposto = t.nextDouble();
     double c;
     c = getSaldo() -  ((percentualimposto/100)*getSaldo()); 
     //System.out.println("C ="+c);
     setSaldo(c);
    }   
}

