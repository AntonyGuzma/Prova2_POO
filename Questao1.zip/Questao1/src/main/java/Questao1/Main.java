/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Questao1;

/**
 *
 * @author Doguinho_a
 */
public class Main {
    public static void main(String[] args ){
        Macaco ma = new Macaco();
        Macaco ma2 = new Macaco();
        ma.setNome("Babuino");
        ma.comer("Banana");
        ma.verbucho();
        ma.digerir();
        System.out.println();
        ma.comer("Maça");
        ma.verbucho();
        ma.digerir();
        System.out.println();
        ma.comer("Abacate");
        ma.verbucho();
        ma.digerir();
        System.out.println();
        ma2.setNome("DonkeyKong");
        ma2.comer("Banana");
        ma2.verbucho();
        ma2.digerir();
        System.out.println();
        ma2.comer("Mamão");
        ma2.verbucho();
        ma2.digerir();
        System.out.println();
        ma2.comer("Ingá");
        ma2.verbucho();
        ma2.digerir();
        System.out.println();
        //Tentei fazer com que o objeto ma comece ma2 mas não deu
        ma.comer(ma2.getNome()); // So funcionou assim, mas nesse caso eu estou acessando o nome do m2 então não conta
    }
}
