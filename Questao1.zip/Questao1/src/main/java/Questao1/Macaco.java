/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Questao1;

/**
 *
 * @author Doguinho_a
 */
public class Macaco {
    private String nome;
    private String estomago;
    private String comida;

    public String getComida() {
        return comida;
    }

    public void setComida(String comida) {
        this.comida = comida;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEstomago() {
        return estomago;
    }

    public void setEstomago(String estomago) {
        this.estomago = estomago;
    }

    
    public void comer(String comida){
        this.comida = comida;
        System.out.println(this.nome+ " esta Comendo " +this.getComida());
    }
    public void verbucho(){
        System.out.println("Na sua barriga tem " +this.getComida());
    }   
    public void digerir(){
        System.out.println("Digerindo " +this.getComida());
    }
    
}