/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Questao4;

/**
 *
 * @author Doguinho_a
 */
public class Main {
    public static void main(String[] args){
        Ingresso in = new Ingresso();
        Ingressovip invp = new Ingressovip();
        in.definirvalor();
        in.imprimir();
        invp.definirvalor();
        invp.preencherpadd();
        invp.imprimir();
        System.out.println("Preço do Ingresso VIP: " +invp.imprimirprecoadicional()+"$");
    }
}
