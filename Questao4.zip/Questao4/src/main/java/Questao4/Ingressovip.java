/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Questao4;

import java.util.Scanner;

/**
 *
 * @author Doguinho_a
 */
public class Ingressovip extends Ingresso{
    private float adicional;
    
    
    public float getAdicional() {
        return adicional;
    }

    public void setAdicional(float adicional) {
        this.adicional = adicional;
    }
    
       public void preencherpadd(){ //Prencher preço adicional
        Scanner t = new Scanner(System.in);
        System.out.println("Preço adicional: ");
        adicional = t.nextFloat();
    }
    
    public float imprimirprecoadicional(){ //Imprimir o novo valor com preço atual incluido
        float a,b,c;
        a = this.getValor();
        b = this.getAdicional();
        c=a+b;
        return c;
    }
}
