/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Questao2;
import java.util.Scanner;

/**
 *
 * @author Doguinho_a
 */
public class Eleitoral {
    private String nome;
    private int idade;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }
    
    public void imprimir(){
        System.out.println("+++++++++++++++++++");
        System.out.println("Nome: " +this.getNome());
        System.out.println("idade: " +this.getIdade());   
        System.out.println("+++++++++++++++++++");
    }
    
    public void verificar(){
        Scanner t = new Scanner(System.in);
        System.out.println("Nome: ");
        nome = t.nextLine();
        System.out.println("Sua idade: ");
        idade = t.nextInt();
        
        if( this.getIdade()<16 ){
            System.out.println();
            System.out.println(this.getNome()+" Não pode Votar");
        }else if(this.getIdade()>=16 && this.getIdade()<=65){
            System.out.println();
            System.out.println(this.getNome()+" Pode Votar");
        }else{
            System.out.println();
            System.out.println(this.getNome()+" Tem voto Facultativo");
        }
   }
}
    
