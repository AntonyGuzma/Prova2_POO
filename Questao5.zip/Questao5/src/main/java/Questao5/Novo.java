/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Questao5;

import java.util.Scanner;


/**
 *
 * @author Doguinho_a
 */
public class Novo extends Imovel {
    public float padd; //Preço  adicional

    public float getPadd() {
        return padd;
    }

    public void setPadd(float padd) {
        this.padd = padd;
    }
    
     public void preencherpadd(){ //Prencher preço adicional
        Scanner t = new Scanner(System.in);
        System.out.println("Preço add: ");
        padd = t.nextFloat();
    }
    
    public void imprimir(){
        float a,b,c;
        a = this.getPreco();
        b = this.getPadd();
        c = a+b;
        System.out.println("Imovel no endereço: "+this.getEndereco());
        System.out.println("Custa: "+a);
        System.out.println("Com adicional de: "+b);
        System.out.println("Seu preço atual é: "+c);
           
    }
    
}
