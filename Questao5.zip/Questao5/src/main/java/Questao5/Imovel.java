/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Questao5;

import java.util.Scanner;

/**
 *
 * @author Doguinho_a
 */
public abstract class Imovel {
    private String endereco;
    private float preco;

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public float getPreco() {
        return preco;
    }

    public void setPreco(float preco) {
        this.preco = preco;
    }
    
     public void preencher(){
        Scanner t = new Scanner(System.in);
        System.out.println("Endereço: ");
        endereco = t.nextLine();
        System.out.println("Preço: ");
        preco = t.nextFloat();
        
    }
}
