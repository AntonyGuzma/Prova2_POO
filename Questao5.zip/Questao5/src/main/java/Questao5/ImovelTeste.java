/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Questao5;

/**
 *
 * @author Doguinho_a
 */
public class ImovelTeste {
     public static void main(String[] args){
        Velho vel = new Velho();
        Novo nov = new Novo();
        nov.preencher();    //Preencher Endereço e Preço
        nov.preencherpadd(); //Prencher Preço adicional
        nov.imprimir(); //Imprimir endereço preço normal e novo preço 
        System.out.println();
        vel.preencher(); //Prencher Endereço e Preço
        vel.desconto(); //Prencher Desconto
        vel.imprimir(); //Imprimir endereço preço normal e novo preço com desconto
        
     }
}
