/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Questao5;

import java.util.Scanner;

/**
 *
 * @author Doguinho_a
 */
public class Velho extends Imovel {
    private float desconto;

    public float getDesconto() {
        return desconto;
    }

    public void setDesconto(float desconto) {
        this.desconto = desconto;
    }
    
    public void desconto(){
       Scanner t = new Scanner(System.in);
        System.out.println("Valor do desconto: ");
        desconto = t.nextFloat();
    }
     
    public void imprimir(){
        float a,b,c;
        a = this.getPreco();
        b = this.getDesconto();
        c = a-b;
        System.out.println("Imovel no endereço: "+this.getEndereco());
        System.out.println("Custa: "+a);
        System.out.println("Com Desconto de: "+b+"$");
        System.out.println("Seu preço atual é: "+c+"$");
           
    }
}
